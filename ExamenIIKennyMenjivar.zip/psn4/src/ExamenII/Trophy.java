package ExamenII;
/**
 *
 * @author kenny
 */
public enum Trophy {
    platino(5),
    oro(3),
    plata(2),
    bronce(1);
    public int puntos;
    private Trophy(int puntos) {
        this.puntos = puntos;
    }
}
