package ExamenII;

/**
 *
 * @author kenny
 */
public class Entry{
    String username;
    long PosicionUser;
    Entry SiguienteUser;
    public Entry(String username, long pos){
        this.username = username;
        this.PosicionUser = pos;
        SiguienteUser = null;
    }
}
