package ExamenII;
/**
 *
 * @author kenny
 */
public class HashTable{
    Entry inicio;
    long tamano=0;
    public void add(String username, long pos){
        if(search(username)!=-1){
        }else{
        Entry newEntry=new Entry(username, pos);
        if (inicio==null){
            inicio=newEntry;
            tamano++;
            return;
        }
        Entry usuario=inicio;
        while(usuario.SiguienteUser!=null){
            usuario=usuario.SiguienteUser;
        }
        tamano++;
        usuario.SiguienteUser=newEntry;
        }
    }
    public void remove(String nameuser){
        if(inicio.username.equals(nameuser)){
            inicio=inicio.SiguienteUser;
            tamano--;
        }else{
        Entry before=inicio;
        Entry current=inicio.SiguienteUser;
        while(current!=null){
            if (current.username.equals(nameuser)){
                before.SiguienteUser=current.SiguienteUser;
                tamano--;
                return;
            }
            before=current;
            current=current.SiguienteUser;
        }
        }
    }
    public long search(String userbuscar){
        Entry actual=inicio;
        long pos=0;
        while(actual!= null){
            if(actual.username.equals(userbuscar)){
                return pos;
            }
            pos++;
            actual=actual.SiguienteUser;
        }
        return -1;
    }
}
