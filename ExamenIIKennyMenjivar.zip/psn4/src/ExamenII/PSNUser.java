package ExamenII;

import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;
public class PSNUser{
    RandomAccessFile raf;
    RandomAccessFile psn;
    HashTable user;
    long tamaño = 0;
    public PSNUser(){
        try{
            raf = new RandomAccessFile("users", "rw");
            psn = new RandomAccessFile("psn", "rw");
            reloadHashTable();
        } catch(FileNotFoundException e){
            try{
                File f = new File("users");
                f.createNewFile();
                f = new File("psn");
                f.createNewFile();
                raf = new RandomAccessFile("users", "rw");
            }catch (Exception ex){
                ex.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void reloadHashTable(){
        tamaño = 0;
        try{
            raf.seek(0);
            user = new HashTable();
            while (raf.getFilePointer() < raf.length()){
                String username = raf.readUTF();
                int trophyPoints = raf.readInt();
                int trophiesCount = raf.readInt();
                boolean registered = raf.readBoolean();
                if (!registered){
                    continue;
                }
                user.add(username, tamaño);
                tamaño++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public boolean addUser(String username){
        if (user.search(username) != -1) {
        }else{
        try{
            raf.seek(raf.length());
            raf.writeUTF(username);
            raf.writeInt(0);
            raf.writeInt(0);
            raf.writeBoolean(true);
            user.add(username, tamaño);
            tamaño++;
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
        return false;
    }
    public void desactivarUser(String username){
        if (user.search(username) == -1){
        }else{
        try{
            File newUsersFile = new File("tempUsers");
            newUsersFile.createNewFile();
            RandomAccessFile newuser = new RandomAccessFile(newUsersFile, "rw");
            raf.seek(0);
            while (raf.getFilePointer() < raf.length()){
               try{
                String currentUsername = raf.readUTF();
                if (username.equals(currentUsername)){
                    raf.skipBytes(4 * 2 + 1);
                    continue;
                }
                int trophyPoints = raf.readInt();
                int trophyCount = raf.readInt();
                newuser.writeUTF(currentUsername);
                newuser.writeInt(trophyPoints);
                newuser.writeInt(trophyCount);
                newuser.writeBoolean(true);
            }catch(EOFException e) {
        break;
    }
            }
            newuser.close();
            raf.close();
            File usersFile = new File("users");
            usersFile.delete();
            newUsersFile.renameTo(usersFile);
            raf = new RandomAccessFile("users", "rw");
            reloadHashTable();
            File tempTrophies = new File("temp");
            tempTrophies.createNewFile();
            RandomAccessFile tempRaf = new RandomAccessFile("temp", "rw");
            psn.seek(0);
            while (psn.getFilePointer() < psn.length()) {
                String currentUsername = psn.readUTF();
                String trophyType = psn.readUTF();
                String trophyGame = psn.readUTF();
                String trophyName = psn.readUTF();
                long date = psn.readLong();
                tempRaf.writeUTF(currentUsername);
                tempRaf.writeUTF(trophyType);
                tempRaf.writeUTF(trophyGame);
                tempRaf.writeUTF(trophyName);
                tempRaf.writeLong(date);
            }
            tempRaf.close();
            psn.close();
            File psnFile = new File("psn");
            psnFile.delete();
            tempTrophies.renameTo(psnFile);
            psn = new RandomAccessFile("psn", "rw");
            eliminarfolder(username);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    }
private void eliminarfolder(String username) {
        String filePath = "user_files/" + username + ".bin";
        File userFile = new File(filePath);
    }
    public boolean addTrophieTo(String username, String trophyGame, String trophyName, Trophy type) {
        if (user.search(username) == -1){
            return false;
        }
         try{
            psn.seek(psn.length());
            psn.writeUTF(username);
            psn.writeUTF(type.name());
            psn.writeUTF(trophyGame);
            psn.writeUTF(trophyName);
            Date currentDate = new Date();
            psn.writeLong(currentDate.getTime());
            raf.seek(0);
            long currentPos =0;
            while (raf.getFilePointer() < raf.length()){
                currentPos = raf.getFilePointer();
                String currentUsername = raf.readUTF();
                if (!currentUsername.equals(username)){
                    raf.skipBytes(4 * 2 + 1);
                    continue;
                }
                int trophyPoints = raf.readInt();
                int trophyCount = raf.readInt();
                boolean registered = raf.readBoolean();
                if (!registered) {
                    return false;
                }
                trophyPoints += type.puntos;
                trophyCount++;
                raf.seek(currentPos);
                raf.writeUTF(currentUsername);
                raf.writeInt(trophyPoints);
                raf.writeInt(trophyCount);
                raf.writeBoolean(true);
                raf.close();
                raf = new RandomAccessFile("users", "rw");
                return true;
            }
            return false;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }
    public String playerInfo(String username){
        if (user.search(username)==-1){
            return "";
        }
        try{
            String salida = "";
            raf.seek(0);
            while (raf.getFilePointer() < raf.length()){
                String currentUsername = raf.readUTF();
                int trophyPoints = raf.readInt();
                int trophyCount = raf.readInt();
                boolean registered = raf.readBoolean();
                if (!currentUsername.equals(username)||!registered){
                    continue;
                }
                salida = "-------------------------\nInformacion de: " + username + "\n-------------------------";
                salida += "\nTotal de puntos por trofeos: " + trophyPoints;
                salida += "\nCantidad de trofeos abquiridos: " + trophyCount;
                salida += "\nInformacion de Trofeos adquiridos: "+"\n";
                psn.seek(0);
                int i=0;
                while(psn.getFilePointer()<psn.length()){
                    String currentPsnUsername=psn.readUTF();
                    String trophyType=psn.readUTF();
                    String trophyGame=psn.readUTF();
                    String trophyName=psn.readUTF();
                    long date = psn.readLong();
                    if (currentPsnUsername.equals(username)){
                    i++;
                      salida+= "Trofeo numero: #"+i+", Nombre: "+trophyName+", Fecha: " + new Date(date)+", Tipo de Juego: "+trophyType+", De: "+trophyGame+"\n";      
                    }
                }
                salida +="\n-------------------------\n";
            }
            return salida;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
    public void close(){
        try{
            raf.close();
            psn.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
